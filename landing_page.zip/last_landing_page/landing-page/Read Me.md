project title landing page

contents css - styles.css\
index.html js - app.js README.md

Installation extract zip file

Usage open index.html file

very helpful project
